import sys
import os


class Cat (object):

    def sound(self):
        print "Meow"
