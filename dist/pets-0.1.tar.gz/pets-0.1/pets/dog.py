import sys
import os


class Dog (object):

    def sound(self):
        print "Wolf"
