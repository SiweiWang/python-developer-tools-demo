"""
pet module
~~~~~~~~~~~~

This package contains code to:

* test package using setup tools

"""

__author__ = 'Siwei Wang'

from pets.dog import Dog
from pets.cat import Cat
